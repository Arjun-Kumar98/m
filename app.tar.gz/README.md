A movie management application front end part using react

1.Add a movie to the list

2.Edit a movie from the list

3.view the movie list

Prerequisites

react

Git (for cloning the repository)

IDE

Getting Started

Clone the repository

cd movie-app to go into the project root

Go to the terminal and run npm-start to start the application
